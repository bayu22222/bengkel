koneksi.php

1
2
3
4
5
6
7
<?php 
// isi nama host, username mysql, dan password mysql anda
mysql_connect("145.14.145.112","root","xxx");
 
// isikan dengan nama database yang akan di hubungkan
mysql_select_db("db_bengkel.sql");
?>